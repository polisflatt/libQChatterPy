# Constants for directories

SERVER_IP_DNS = "http://174.97.129.196/QChatter/QChatterServer/"
CHANNELS_DIR = "Channel/"
MESSAGES_DIR = "Message/"
